'use strict';

System.register(['app/plugins/sdk'], function (_export, _context) {
  "use strict";

  var PanelCtrl, _typeof, _createClass, panelDefaults, LivyCtrl;

  function _classCallCheck(instance, Constructor) {
    if (!(instance instanceof Constructor)) {
      throw new TypeError("Cannot call a class as a function");
    }
  }

  function _possibleConstructorReturn(self, call) {
    if (!self) {
      throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    }

    return call && (typeof call === "object" || typeof call === "function") ? call : self;
  }

  function _inherits(subClass, superClass) {
    if (typeof superClass !== "function" && superClass !== null) {
      throw new TypeError("Super expression must either be null or a function, not " + typeof superClass);
    }

    subClass.prototype = Object.create(superClass && superClass.prototype, {
      constructor: {
        value: subClass,
        enumerable: false,
        writable: true,
        configurable: true
      }
    });
    if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass;
  }

  return {
    setters: [function (_appPluginsSdk) {
      PanelCtrl = _appPluginsSdk.PanelCtrl;
    }],
    execute: function () {
      _typeof = typeof Symbol === "function" && typeof Symbol.iterator === "symbol" ? function (obj) {
        return typeof obj;
      } : function (obj) {
        return obj && typeof Symbol === "function" && obj.constructor === Symbol && obj !== Symbol.prototype ? "symbol" : typeof obj;
      };

      _createClass = function () {
        function defineProperties(target, props) {
          for (var i = 0; i < props.length; i++) {
            var descriptor = props[i];
            descriptor.enumerable = descriptor.enumerable || false;
            descriptor.configurable = true;
            if ("value" in descriptor) descriptor.writable = true;
            Object.defineProperty(target, descriptor.key, descriptor);
          }
        }

        return function (Constructor, protoProps, staticProps) {
          if (protoProps) defineProperties(Constructor.prototype, protoProps);
          if (staticProps) defineProperties(Constructor, staticProps);
          return Constructor;
        };
      }();

      panelDefaults = {
        rmServer: 'http://yarn-rm-host:8088',
        livyServer: 'http://livy-host:8999',
        submitJar: 'hdfs:///path/to/file.jar',
        jobClassName: 'com.full.job.ClassName',
        satTemplateVar: 'sat'
      };

      _export('LivyCtrl', LivyCtrl = function (_PanelCtrl) {
        _inherits(LivyCtrl, _PanelCtrl);

        function LivyCtrl($scope, $injector, $http) {
          _classCallCheck(this, LivyCtrl);

          var _this = _possibleConstructorReturn(this, (LivyCtrl.__proto__ || Object.getPrototypeOf(LivyCtrl)).call(this, $scope, $injector));

          _.defaults(_this.panel, panelDefaults);

          _this.$http = $http;
          _this.serverState = 'connecting';
          _this.events.on('init-edit-mode', _this.onInitEditMode.bind(_this));

          _this.updateJobs();
          return _this;
        }

        _createClass(LivyCtrl, [{
          key: 'onInitEditMode',
          value: function onInitEditMode() {
            this.addEditorTab('Options', 'public/plugins/livy-panel/editor.html', 2);
          }
        }, {
          key: 'updateJobs',
          value: function updateJobs() {
            var _this2 = this;

            var batches = this.$http.get(this.panel.livyServer + '/batches');
            var sessions = this.$http.get(this.panel.livyServer + '/sessions');

            batches.then(function (response) {
              _this2.batches = response.data;
              _this2.serverState = 'online';
            }, function (error) {
              return _this2.serverState = 'offline';
            });

            sessions.then(function (response) {
              return _this2.sessions = response.data;
            }, function (error) {
              return _this2.serverState = 'offline';
            });

            this.$timeout(function () {
              _this2.updateJobs();
            }, 2000);
          }
        }, {
          key: 'canSubmit',
          value: function canSubmit() {
            return _typeof(this.dashboard.time.from) === "object" && this.serverState === 'online' && this.requestState !== 'pending';
          }
        }, {
          key: 'submitJob',
          value: function submitJob() {
            var _this3 = this;

            var request = this.$http.post(this.panel.livyServer + '/batches', {
              "file": this.panel.submitJar,
              "className": this.panel.jobClassName,
              "args": [this.dashboard.time.from.format('x'), this.dashboard.time.to.format('x'), _.find(this.dashboard.templating.list, { name: this.panel.satTemplateVar }).current.value]
            });

            this.serverState = 'pending';

            request.then(function (response) {
              _this3.serverState = 'success';
              _this3.batches.sessions.push(response.data);
            }, function (error) {
              return _this3.serverState = 'error';
            });
          }
        }, {
          key: 'killBatch',
          value: function killBatch(id) {
            var _this4 = this;

            var request = this.$http.delete(this.panel.livyServer + '/batches/' + id);
            this.serverState = 'pending';
            request.then(function (response) {
              return _this4.serverState = 'success';
            }, function (error) {
              return _this4.serverState = 'error';
            });
          }
        }, {
          key: 'killSession',
          value: function killSession(id) {
            var _this5 = this;

            var request = this.$http.delete(this.panel.livyServer + '/sessions/' + id);
            this.serverState = 'pending';
            request.then(function (response) {
              return _this5.serverState = 'success';
            }, function (error) {
              return _this5.serverState = 'error';
            });
          }
        }]);

        return LivyCtrl;
      }(PanelCtrl));

      _export('LivyCtrl', LivyCtrl);

      LivyCtrl.templateUrl = 'module.html';
    }
  };
});
//# sourceMappingURL=livy_ctrl.js.map
